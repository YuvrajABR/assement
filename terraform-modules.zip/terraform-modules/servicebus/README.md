```json
    { 
servicebus = {
  "sevicebus1" = {
    resource-group-name                 = "demo-terraform-rg"
    location                            = "UK South"
    sku                                 = "Standard"   # Possible inputs [Basic, Premium]
    capacity                            = 0
    tags =  {
      service_name =  "servicename"
      service_owner = "serviceowner"
      environment   = "env"
      cost_code     = "costcode"
     } 
    }```
