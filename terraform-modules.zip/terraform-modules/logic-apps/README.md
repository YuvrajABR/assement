```json
{ 
logicapps = {
  logicapp1= {
    app_service_plan_name = "ASP-demoterraformrg-bd25"
    storage_account_name = "azustfdemoeng001"
    resource_group_name = "demo-terraform-rg"
    location = "UK South"
    tags =  {
      service_name =  "servicename"
      service_owner = "serviceowner"
      environment   = "env"
      cost_code     = "costcode"
     }}}
    }
```
