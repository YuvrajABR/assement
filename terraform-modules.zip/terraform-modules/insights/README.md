```json
    { 
app-insights = {
  azsu-p-014-ain01 = {
    location = "UK South"
    resource-group-name = "demo-terraform-rg"
    type = "web" 
    are-data-cap-notifications-disabled = true
    retention-in-days = 90
    sampling-percentage = null
    is-ip-masking-disabled = false
    law-id = "/subscriptions/8d2ad506-3557-4348-b7e8-fed3ecc0fcd6/resourceGroups/demo-terraform-rg/providers/Microsoft.OperationalInsights/workspaces/defaultworkspace-8d2ad506-3557-4348-b7e8-fed3ecc0fcd6-suk"
    is-local-auth-disabled = false
    tags =  {
      service_name =  "servicename"
      service_owner = "serviceowner"
      environment   = "env"
      cost_code     = "costcode"
     }}
     }
    }```
