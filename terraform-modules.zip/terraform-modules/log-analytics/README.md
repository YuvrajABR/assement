```json
    { 
log-analytics-workspaces = {
 azsu-law-01 = {
   location = "UK South"
   resource-group = "demo-terraform-rg"
   tier = "PerGB2018"
   retention-in-days = 30
   tags =  {
      service_name =  "servicename"
      service_owner = "serviceowner"
      environment   = "env"
      cost_code     = "costcode"
     }
   solutions = {
     AzureSQLAnalytics = {
       publisher = "Microsoft"
       product = "OMSGallery/AzureSQLAnalytics"
       promotion-code = null
     }
     AzureDataFactoryAnalytics = {
       publisher = "Microsoft"
       product = "OMSGallery/AzureDataFactoryAnalytics"
       promotion-code = null
     }}}
}
    }```
