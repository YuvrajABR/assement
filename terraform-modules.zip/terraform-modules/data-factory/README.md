```json
    { 
data-factories = {
  azsu-p-001-adf01 = {
    resource-group-name = "demo-terraform-rg"
    location = "UK South"
    is-public-network-enabled = false
    is-managedvnet-enabled = false
    tags =  {
      service_name =  "servicename"
      service_owner = "serviceowner"
      environment   = "env"
      cost_code     = "costcode"
     }
    runtime-integrations = {
      self = {}
#        azsu-p-001-ir-fira = {
#          description = "Self hosted integration runtime for FIRA"
#        }
      managed = {
       azsu-p-001-ir-fira = {
        core-count = 8
        compute-type = "General"
        is-vnet-enabled = true
       }
      }
    }
    // identity-type = "SystemAssigned"
    // identity-names = null
    // role-assignments = {}
    linked-services = {
      databricks = {}
      #Terraform module for Synapse linked service doesn't support MI or private endpoints yet - Configuration has been hand cranked
    }
    }```
