```json
    { 
functionappslinux = {
 functionapp1= {
    app_os = ["Linux"]    # Possible Inputs [Windows]
    apps = [
      {
        name = "webapp1"
      }
    ]
    app_service_plan_name = "ASP-demoterraformrg-9aac"
    storage_account_name = "azustfdemoeng001"
    resource_group_name = "demo-terraform-rg"
    location = "UK South"
    app_insights_name = "terraform-test-insights"
    log_analytics_name = "terraform-test"
    app_insights_rg_name = "demo-terraform-rg"
    log_analytics_rg_name = "demo-terraform-rg"
    tags =  {
      service_name =  "servicename"
      service_owner = "serviceowner"
      environment   = "env"
      cost_code     = "costcode"
     }
    runtime = "java"       # Possible Inputs [.NET, Node.js, Python]
    dotnet_version = ""
    java_version        = "11"
    node_version        = ""
    powershell_core_version = ""
    python_version = ""
    app_settings = {
    }}}
    }```
