```json
    { 
key-vaults = {
  azsu-p-003-vault01 = {
    location = "UK South"
    resource-group-name = "demo-terraform-rg"
    sku = "standard"        # Possible inputs [Premium, Premium_hsm]
    enable-purge-protection = true
    enable-for-deployments = false
    enable-for-disk-encryption = false
    enable-for-template-deployment = false
    tags =  {
      service_name =  "servicename"
      service_owner = "serviceowner"
      environment   = "env"
      cost_code     = "costcode"
     }
    policies = {
      VSTS_BigData = {
        tenant = null
        //object = null
        type = "service principal"
        key-permissions = [
          "backup",
          "create",
          "decrypt",
          "delete",
          "encrypt",
          "get",
          "import",
          "list",
          "purge",
          "recover",
          "restore",
          "sign",
          "unwrapKey",
          "update",
          "verify",
         "wrapKey"
        ]
        secret-permissions = [
          "backup",
          "delete",
          "get",
          "list",
          "purge",
          "recover",
          "restore",
          "set"
        ]
        storage-permissions = [
          "backup",
          "delete",
          "deletesas",
          "get",
          "getsas",
          "list",
          "listsas",
          "purge",
          "recover",
          "regeneratekey",
          "restore",
          "set",
          "setsas",
          "update"
        ]
        certificate-permissions = [
          "backup",
          "create",
          "delete",
          "deleteissuers",
          "get",
          "getissuers",
          "import",
          "list",
          "listissuers",
          "managecontacts",
          "manageissuers",
          "purge",
          "recover",
          "restore",
          "setissuers",
          "update"
        ]
      }
      g-ds-platformengineering = {
        tenant = null
        type = "group"
        key-permissions = []
        secret-permissions = [
          "get",
          "list"
        ]
        storage-permissions = []
        certificate-permissions = [
          "get",
          "getissuers",
          "list",
          "listissuers"
        ]
      }
#      azsu-p-003-adf01 = {
#        tenant = null
#        type = "" 
#        key-permissions = []
#        secret-permissions = [
#          "get",
#          "list"
#        ]
#        storage-permissions = []
#        certificate-permissions = []
#      }
    }
    secrets = {}
      secret1={
       value = "your-secret-value"
       content_type = "application/json"
       not_before_date = "2023-01-01T00:00:00Z"
       expiration_date = "2023-01-01T12:00:00Z"
      }
      secret2={
       value = "another-secret-value"
       content_type = "application/json"
       not_before_date = "2023-01-01T00:00:00Z"
       expiration_date = "2023-01-01T12:00:00Z"
      }
    keys = {}
  }
}
    }```
