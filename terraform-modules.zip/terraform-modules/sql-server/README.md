```json
    { 
sql-servers = {
  azwu-u-003-sql01 = {
    resource_group_name = "demo-terraform-rg"
    location = "UK South"
    version = "12.0"
    # aad-admin-group-name = null
    min-tls = "1.2"
    connection-policy = "Default"
    identity-type = "SystemAssigned"  # Possible inputs [UserAssigned, None]
    databases = {
      fop_d365 = {
        creation-mode = "Default"
        import = null
        license-type = "BasePrice"  # Possible inputs [LicenseIncluded]
        src-db-id = null
        create-sample-schema = false
        read-replica-count = null
        restore-dt = null
        collation = "SQL_LATIN1_GENERAL_CP1_CI_AS"
        max-size-gbs = 500
        sku = "GP_Gen5_8" # Possible inputs [Basic, Standar, Premium, BusinessCritical]
        is-zone-redundant = false
        charset = "utf8"
}
    
  }
  tags =  {
      service_name =  "servicename"
      service_owner = "serviceowner"
      environment   = "env"
      cost_code     = "costcode"
     }}}
    }```
