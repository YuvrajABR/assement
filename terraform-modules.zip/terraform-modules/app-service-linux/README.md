```json
    { 
    app-service-plans = {
  "plan1" = {
    resource_group_name = "demo-terraform-rg"
    location            = "UK South"
    os_type             = "Linux"             # Possible Inputs [Windows]
    sku_name            =  "B1"               # Possible Inputs [B1, B2, B3, F1, F2, F3, S1, S2, S3, P1, P2, P3, P1V2, P2V2, P3V2, P1V3, P2V3, P3V3, I1, I2, I3, I1v2, I2v2, I3v2]
    tags =  {
      service_name =  "servicename"
      service_owner = "serviceowner"
      environment   = "env"
    }
    runtime_stack = "java"  # Possible Inputs [ASP.NET, Node.js, Python, Ruby, PHP, Go]
    dotnet_version = ""
    go_version = ""
    php_version = ""
    node_version = ""
    java_server  = ""
    java_server_version =""
    java_version = "8"
    python_version = ""
    ruby_version =""
    }
  }
    }```
