```json
    { 
appserviceswindows = {
  app1 = {
    app_os = ["Windows"],  # Possible Inputs [Windows]
    apps = [
      {
        name = "app1"
      }
    ],
    app_service_plan_name = "ASP-demoterraformrg-bd25"  # Same app service plan name for multiple app services
    resource_group_name = "demo-terraform-rg"
    location = "UK South"
    app_insights_name = "terraform-test-insights"
    log_analytics_name = "terraform-test"
    app_insights_rg_name = "demo-terraform-rg"
    log_analytics_rg_name = "demo-terraform-rg"
    tags =  {
      service_name =  "servicename"
      service_owner = "serviceowner"
      environment   = "env"
    }
    runtime_stack = "java"  # Possible Inputs [ASP.NET, Node.js, Python, Ruby, PHP, Go]
    dotnet_version = ""
    go_version = ""
    php_version = ""
    node_version = ""
    java_server  = ""
    java_server_version =""
    java_version = "8"
    python_version = ""
    ruby_version =""
    }
  }
    }```
