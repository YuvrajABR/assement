```json
    { 
storage-accounts = {
  azustfdemoeng001 = {
    resource-group-name                 = "demo-terraform-rg"
    location                            = "UK South"
    account-tier                        = "Standard"
    account-kind                        = "StorageV2"
    min-tls                             = "TLS1_2"
    replication-type                    = "LRS"
    https-only                          = true
    is-hns-enabled                      = false
    allow-public-nested-items           = true
    allow_nested_items_to_be_public     = false
    is-cross-tenant-replication-enabled = true
    identity                            = "SystemAssigned"
    public_network_access_enabled       = false
    enable_blob_public_access           = false
    access_tier                         = "Cool"
    tags =  {
      service_name =  "servicename"
      service_owner = "serviceowner"
      environment   = "env"
      cost_code     = "costcode"
     }
    containers = {
      container1 = {
        access-type = "private"
        metadata = {}
      }
      container2 = {
        access-type = "private"
        metadata = {}
      }
    }
    file-shares                         = {}
    adlsv2-filesystems                  = {}
    tables                              = {}
    queues                              = {}
    shares                              = {}
    data_lake_filesystems               = {}
    tags = {
      costcodeid   = "storageacc12"
      servicename  = "tfdemo"
      serviceowner = "poornima"
      environment  = "demo"
    }
    }```
